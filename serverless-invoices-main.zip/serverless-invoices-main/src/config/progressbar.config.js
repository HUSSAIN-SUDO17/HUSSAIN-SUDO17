export default {
  color: 'var(--primary)',
  failedColor: 'var(--error)',
  thickness: '2px',
};
