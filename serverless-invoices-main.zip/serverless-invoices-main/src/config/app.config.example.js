// const wordpress = window.name ? JSON.parse(window.name) : { front_url: '', api_url: '', nonce: '' };

export default {
  storageType: 'local',
  // base_url: wordpress.front_url,
  // base_url: `${window.location.origin}${process.env.BASE_URL}`
  // api_url: wordpress.api_url,
  // api_nonce: wordpress.nonce,
};
