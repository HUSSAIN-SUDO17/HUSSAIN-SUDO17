<template>
    <div>
        <InvoiceForm/>
    </div>
</template>

<script>
import InvoiceForm from '../components/invoices/InvoiceForm';

export default {
  name: 'client',
  components: {
    InvoiceForm,
  },
  computed: {},
  methods: {},
};
</script>
